#!/bin/bash

NAMESPACE="objs-fed"
DEPLOY_NAME="backend"
TARGET="http://backend.objs-fed.svc.cluster.local:7000"
DURATION="30s"
RATE="10/s"

# Log times
echo "[$(date)] Starting Vegeta test"
echo "[$(date)] Triggering health failure"

# Trigger /fail
kubectl exec -n $NAMESPACE deploy/$DEPLOY_NAME -c health-controller -- \
  wget -qO- http://localhost:8081/fail

# Start vegeta attack
echo "GET $TARGET" | vegeta attack -rate=$RATE -duration=$DURATION | tee results.bin | vegeta report > report.txt &

# Wait ~30 seconds
sleep 30

echo "[$(date)] Restoring health"
kubectl exec -n $NAMESPACE deploy/$DEPLOY_NAME -c health-controller -- \
  wget -qO- http://localhost:8081/ok

# Wait for Vegeta to finish
wait

# Optional: Visualize
vegeta plot < results.bin > plot.html
echo "Plot saved to plot.html"

